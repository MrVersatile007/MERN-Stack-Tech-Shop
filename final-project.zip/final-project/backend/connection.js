require('dotenv').config();

const mongoose = require('mongoose');

const connectionStr = "mongodb+srv://kairam42:C11H22O11issucrose@cluster0.kvnagkx.mongodb.net/project?retryWrites=true&w=majority"

mongoose.connect(connectionStr, {useNewUrlparser: true})
.then(() => console.log('connected to mongodb'))
.catch(err => console.log(err))

mongoose.connection.on('error', err => {
  console.log(err)
})
